let singleScene = new Phaser.Scene('Single');

singleScene.preload = function(){

}

singleScene.create = function(){

    let returnToMenu = this.add.image(this.game.renderer.width / 2, this.game.renderer.height /2, "returntomenu").setDepth(1);   
    returnToMenu.setInteractive();

    returnToMenu.on("pointerover", ()=>{
        console.log("return to menu hovering")
    })

    returnToMenu.on("pointerout", ()=>{
        console.log("return to menu exit")
    })

    returnToMenu.on("pointerdown", ()=>
        clickReturnMenuButton());
}

singleScene.update = function(){
    
}

function clickReturnMenuButton(){
    console.log("return to menu");
    game.scene.stop('Single');
    game.scene.start('Multi');
    
}

